# Kalkulator-w-Pythonie
To repozytorium służy do ćwiczeń .
